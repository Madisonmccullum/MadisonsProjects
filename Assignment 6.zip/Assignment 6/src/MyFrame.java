// Madison McCullum, Advanced Programming and data structures
// The purpose of this MyFrame class is to create a chessboard,
// randomize pieces onto the chessboard and highlight the areas
// that these pieces can move to when clicked on

import javax.swing.JFrame;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.*;
public class MyFrame extends JFrame implements MouseListener {


    chessButton[] board = new chessButton[64];

    MyFrame() {

        // creating j frame with grid lay out
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(new GridLayout(8, 8));
        this.setResizable(false);
        this.setSize(500, 500);
        this.setTitle("Chessboard");

        // adding buttons to the board with checkered component
        for (int i = 0; i < 64; i++) {
            board[i] = new chessButton(i);
            board[i].setOpaque(true);
            board[i].addMouseListener(this);
            this.add(board[i]);
        }
        for (int i = 0; i < 64; i++) {
            rePaint();
        }


        // array list full of numbers of the checkerboard
        ArrayList<Integer> nums = new ArrayList<Integer>();
        for (int i = 0; i < 64; i++) {
            nums.add(i);
        }

        // creating random variable
        Random ran = new Random();

        // adding the players to the board
        // adding white queen to checkerboard
        int nxt = ran.nextInt(nums.size());
        board[nums.get(nxt)].setForeground(Color.white);
        board[nums.get(nxt)].setPlayer("Q");
        nums.remove(nxt);

        // adding black queen to checkerboard
        nxt = ran.nextInt(nums.size());
        board[nums.get(nxt)].setPlayer("Q");
        nums.remove(nxt);

        // adding white king to checkerboard
        nxt = ran.nextInt(nums.size());
        board[nums.get(nxt)].setPlayer("K");
        board[nums.get(nxt)].setForeground(Color.white);
        nums.remove(nxt);

        // adding black king to checkerboard
        nxt = ran.nextInt(nums.size());
        board[nums.get(nxt)].setPlayer("K");
        nums.remove(nxt);

        // adding 2 white knights to checkerboard
        for (int i = 0; i < 2; i++) {
            nxt = ran.nextInt(nums.size());
            board[nums.get(nxt)].setPlayer("Kn");
            board[nums.get(nxt)].setForeground(Color.white);
            nums.remove(nxt);
        }

        // adding 2 black knights to checkerboard
        for (int i = 0; i < 2; i++) {
            nxt = ran.nextInt(nums.size());
            board[nums.get(nxt)].setPlayer("Kn");
            nums.remove(nxt);
        }

        // adding 2 white bishops to checkerboard
        for (int i = 0; i < 2; i++) {
            nxt = ran.nextInt(nums.size());
            board[nums.get(nxt)].setPlayer("B");
            board[nums.get(nxt)].setForeground(Color.white);
            nums.remove(nxt);
        }

        // adding 2 black bishops to checkerboard
        for (int i = 0; i < 2; i++) {
            nxt = ran.nextInt(nums.size());
            board[nums.get(nxt)].setPlayer("B");
            nums.remove(nxt);
        }

        // adding 8 white pawns to checkerboard
        for (int i = 0; i < 8; i++) {
            nxt = ran.nextInt(nums.size());
            board[nums.get(nxt)].setPlayer("P");
            board[nums.get(nxt)].setForeground(Color.white);
            nums.remove(nxt);
        }

        // adding 8 black pawns to checkerboard
        for (int i = 0; i < 8; i++) {
            nxt = ran.nextInt(nums.size());
            board[nums.get(nxt)].setPlayer("P");
            nums.remove(nxt);
        }

        // adding 2 white rooks to checkerboard
        for (int i = 0; i < 2; i++) {
            nxt = ran.nextInt(nums.size());
            board[nums.get(nxt)].setPlayer("R");
            board[nums.get(nxt)].setForeground(Color.white);
            nums.remove(nxt);
        }

        // adding 2 black rooks to checkerboard
        for (int i = 0; i < 2; i++) {
            nxt = ran.nextInt(nums.size());
            board[nums.get(nxt)].setPlayer("R");
            nums.remove(nxt);
        }

        this.setVisible(true);


    }


    @Override
    public void mouseClicked(MouseEvent e) {
        for (int i = 0; i < 64; i++) {
            if (e.getSource() == board[i]) {
                rePaint();
                if(board[i].getPlayer().equals("K") ){
                    paintKing(i);
                }
                if(board[i].getPlayer().equals("Kn") ){
                    paintKnight(i);
                }
                if(board[i].getPlayer().equals("Q") ){
                    paintQueen(i);
                }
                if(board[i].getPlayer().equals("R") ){
                    paintRook(i);
                }
                if(board[i].getPlayer().equals("B") ){
                    paintBishop(i);
                }
                if(board[i].getPlayer().equals("P") ){
                    paintPawn(i);
                }
                if(board[i].getPlayer().equals("null")){
                    paintEmpty();
                }
            }
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
        for (int i = 0; i < 64; i++) {
            if (e.getSource() == board[i]) {
                rePaint();
                if(board[i].getPlayer().equals("K") ){
                    paintKing(i);
                }
                if(board[i].getPlayer().equals("Kn") ){
                    paintKnight(i);
                }
                if(board[i].getPlayer().equals("Q") ){
                    paintQueen(i);
                }
                if(board[i].getPlayer().equals("R") ){
                    paintRook(i);
                }
                if(board[i].getPlayer().equals("B") ){
                    paintBishop(i);
                }
                if(board[i].getPlayer().equals("P") ){
                    paintPawn(i);
               }
                if(board[i].getPlayer().equals("null")){
                    paintEmpty();
                }
            }
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    // method that repaints the whole board to its original checkered state
    public void rePaint(){
        for(int i = 0; i < 64; i++){
            if (i % 2 == 0) {
                if (i < 8 || i > 15 && i < 24 || i > 31 && i < 40 || i > 47 && i < 56) {
                    board[i].setBackground(new Color(248, 200, 220));
                } else {
                    board[i].setBackground(new Color(218, 112, 214));
                }
            }
            if (i % 2 != 0) {
                if (i > 7 && i < 16 || i > 23 && i < 32 || i > 39 && i < 48 || i > 55 && i < 64) {
                    board[i].setBackground(new Color(248, 200, 220));
                } else {
                    board[i].setBackground(new Color(218, 112, 214));
                }
            }
        }
    }

    // Method that, when called, opens a new window with instructions on the players movements
    public void paintEmpty(){
        JFrame n = new NewFrame();
    }

    // Methods that highlight the possible movements for each player
    public void paintQueen(int x) {
        for (int i = x + 8; i < 65; i += 8) {
            if (board[i].isEmpty()) {
                board[i].setBackground(new Color(246,173,90));
            } else {
                if (board[x].getForeground().equals(board[i].getForeground())) {
                    break;
                } else {
                    board[i].setBackground(new Color(246,173,90));
                    break;
                }
            }
        }
        for (int i = x - 8; i > -1; i -= 8) {
            if (board[i].isEmpty()) {
                board[i].setBackground(new Color(246,173,90));
            } else {
                if(board[x].getForeground().equals(board[i].getForeground())){
                    break;
                }
                else{
                    board[i].setBackground(new Color(246,173,90));
                    break;
                }
            }
        }
        for (int i = x + 1; i < x + (8 - (x % 8)); i++) {
            if (board[i].isEmpty()) {
                board[i].setBackground(new Color(246,173,90));
            } else {
                if(board[x].getForeground().equals(board[i].getForeground())){
                    break;
                }
                else{
                    board[i].setBackground(new Color(246,173,90));
                    break;
                }
            }
        }
        for (int i = x - 1; i > x - (x % 8 + 1); i--) {
            if (board[i].isEmpty()) {
                board[i].setBackground(new Color(246,173,90));
            } else {
                if(board[x].getForeground().equals(board[i].getForeground())){
                    break;
                }
                else{
                    board[i].setBackground(new Color(246,173,90));
                    break;
                }
            }
        }

        for(int i = x - 9; i > -1; i-=9){
            if(x%8 == 0){
                break;
            }
            if (board[i].isEmpty()) {
                board[i].setBackground(new Color(246,173,90));
            } else {
                if (board[x].getForeground().equals(board[i].getForeground())) {
                    break;
                } else {
                    board[i].setBackground(new Color(246,173,90));
                    break;
                }
            }
            if(i%8 == 0){
                break;
            }
        }
        for(int i = x - 7; i > -1; i-=7){
            if((x+1)%8 == 0){
                break;
            }
            if (board[i].isEmpty()) {
                board[i].setBackground(new Color(246,173,90));
            } else {
                if (board[x].getForeground().equals(board[i].getForeground())) {
                    break;
                } else {
                    board[i].setBackground(new Color(246,173,90));
                    break;
                }
            }
            if((i+1)%8 == 0){
                break;
            }
        }
        for(int i = x + 7; i < 64; i+=7){
            if(x%8 == 0){
                break;
            }
            if (board[i].isEmpty()) {
                board[i].setBackground(new Color(246,173,90));
            } else {
                if (board[x].getForeground().equals(board[i].getForeground())) {
                    break;
                } else {
                    board[i].setBackground(new Color(246,173,90));
                    break;
                }
            }
            if(i%8 == 0){
                break;
            }
        }
        for(int i = x+9; i < 64; i+=9){
            if((x+1)%8 == 0){
                break;
            }
            if (board[i].isEmpty()) {
                board[i].setBackground(new Color(246,173,90));
            } else {
                if (board[x].getForeground().equals(board[i].getForeground())) {
                    break;
                } else {
                    board[i].setBackground(new Color(246,173,90));
                    break;
                }
            }
            if((i+1)%8 == 0){
                System.out.println("yes");
                break;
            }
        }

    }

    public void paintRook(int x) {
        for (int i = x + 8; i < 65; i += 8) {
            if (board[i].isEmpty()) {
                board[i].setBackground(new Color(246,96,90));
            } else {
                if (board[x].getForeground().equals(board[i].getForeground())) {
                    break;
                } else {
                    board[i].setBackground(new Color(246,96,90));
                    break;
                }
            }
        }
        for (int i = x - 8; i > -1; i -= 8) {
            if (board[i].isEmpty()) {
                board[i].setBackground(new Color(246,96,90));
            } else {
                if(board[x].getForeground().equals(board[i].getForeground())){
                    break;
                }
                else{
                    board[i].setBackground(new Color(246,96,90));
                    break;
                }
            }
        }
        for (int i = x + 1; i < x + (8 - (x % 8)); i++) {
            if (board[i].isEmpty()) {
                board[i].setBackground(new Color(246,96,90));
            } else {
                if(board[x].getForeground().equals(board[i].getForeground())){
                    break;
                }
                else{
                    board[i].setBackground(new Color(246,96,90));
                    break;
                }
            }
        }
        for (int i = x - 1; i > x - (x % 8 + 1); i--) {
            if (board[i].isEmpty()) {
                board[i].setBackground(new Color(246,96,90));
            } else {
                if(board[x].getForeground().equals(board[i].getForeground())){
                    break;
                }
                else{
                    board[i].setBackground(new Color(246,96,90));
                    break;
                }
            }
        }
    }

    public void paintBishop(int x){

        for(int i = x - 9; i > -1; i-=9){
            if(x%8 == 0){
                break;
            }
            if (board[i].isEmpty()) {
                board[i].setBackground(new Color(241,245,141));
            } else {
                if (board[x].getForeground().equals(board[i].getForeground())) {
                    break;
                } else {
                    board[i].setBackground(new Color(241,245,141));
                    break;
                }
            }
            if(i%8 == 0){
                break;
            }
        }
        for(int i = x - 7; i > -1; i-=7){
            if((x+1)%8 == 0){
                break;
            }
            if (board[i].isEmpty()) {
                board[i].setBackground(new Color(241,245,141));
            } else {
                if (board[x].getForeground().equals(board[i].getForeground())) {
                    break;
                } else {
                    board[i].setBackground(new Color(241,245,141));
                    break;
                }
            }
            if((i+1)%8 == 0){
                break;
            }
        }
        for(int i = x + 7; i < 64; i+=7){
            if(x%8 == 0){
                break;
            }
            if (board[i].isEmpty()) {
                board[i].setBackground(new Color(241,245,141));
            } else {
                if (board[x].getForeground().equals(board[i].getForeground())) {
                    break;
                } else {
                    board[i].setBackground(new Color(241,245,141));
                    break;
                }
            }
            if(i%8 == 0){
                break;
            }
        }
        for(int i = x+9; i < 64; i+=9){
            if((x+1)%8 == 0){
                break;
            }
            if (board[i].isEmpty()) {
                board[i].setBackground(new Color(241,245,141));
            } else {
                if (board[x].getForeground().equals(board[i].getForeground())) {
                    break;
                } else {
                    board[i].setBackground(new Color(241,245,141));
                    break;
                }
            }
            if((i+1)%8 == 0){
                System.out.println("yes");
                break;
            }
        }
    }

    public void paintKing(int x){

        if(x%8 != 0){
            if (x-9 > -1) {
                if (board[x-9].isEmpty()){
                    board[x-9].setBackground(new Color(158,247,200));
                }
                else{
                    if(!board[x-9].getForeground().equals(board[x].getForeground())){
                        board[x-9].setBackground(new Color(158,247,200));
                    }
                }
            }
            if (x-1 > -1) {
                if (board[x-1].isEmpty()){
                    board[x-1].setBackground(new Color(158,247,200));
                }
                else{
                    if(!board[x-1].getForeground().equals(board[x].getForeground())){
                        board[x-1].setBackground(new Color(158,247,200));
                    }
                }
            }
            if (x+7 < 64 ) {
                if (board[x+7].isEmpty()){
                    board[x+7].setBackground(new Color(158,247,200));
                }
                else{
                    if(!board[x+7].getForeground().equals(board[x].getForeground())){
                        board[x+7].setBackground(new Color(158,247,200));
                    }
                }
            }
        }

        if((x+1)%8 != 0){
            if (x-7 > -1) {
                if (board[x-7].isEmpty()){
                    board[x-7].setBackground(new Color(158,247,200));
                }
                else{
                    if(!board[x-7].getForeground().equals(board[x].getForeground())){
                        board[x-7].setBackground(new Color(158,247,200));
                    }
                }
            }
            if (x+1 < 64) {
                if (board[x+1].isEmpty()){
                    board[x+1].setBackground(new Color(158,247,200));
                }
                else{
                    if(!board[x+1].getForeground().equals(board[x].getForeground())){
                        board[x+1].setBackground(new Color(158,247,200));
                    }
                }
            }
            if (x+9 < 64) {
                if (board[x+9].isEmpty()){
                    board[x+9].setBackground(new Color(158,247,200));
                }
                else{
                    if(!board[x+9].getForeground().equals(board[x].getForeground())){
                        board[x+9].setBackground(new Color(158,247,200));
                    }
                }
            }
        }

        if (x-8 > -1) {
            if (board[x-8].isEmpty()){
                board[x-8].setBackground(new Color(158,247,200));
            }
            else{
                if(!board[x-8].getForeground().equals(board[x].getForeground())){
                    board[x-8].setBackground(new Color(158,247,200));
                }
            }
        }
        if (x+8 < 64) {
            if (board[x+8].isEmpty()){
                board[x+8].setBackground(new Color(158,247,200));
            }
            else{
                if(!board[x+8].getForeground().equals(board[x].getForeground())){
                    board[x+8].setBackground(new Color(158,247,200));
                }
            }
        }

    }

    public void paintKnight(int x) {
        if(x%8 != 0 && (x-1)%8 != 0){
            if (x-10 > -1) {
                if(board[x-10].isEmpty()){
                    board[x - 10].setBackground(new Color(154,177,252));
                }
                else if (!board[x-10].getForeground().equals(board[x].getForeground())){
                    board[x - 10].setBackground(new Color(154,177,252));
                }
            }
            if (x+6 < 64) {
                if(board[x+6].isEmpty()){
                    board[x +6].setBackground(new Color(154,177,252));
                }
                else if (!board[x+6].getForeground().equals(board[x].getForeground())){
                    board[x+6].setBackground(new Color(154,177,252));
                }
            }
        }
        if(x%8 !=0 ){
            if (x-17 > -1) {
                if(board[x-17].isEmpty()){
                    board[x - 17].setBackground(new Color(154,177,252));
                }
                else if (!board[x-17].getForeground().equals(board[x].getForeground())){
                    board[x - 17].setBackground(new Color(154,177,252));
                }
            }
            if (x+15 < 64) {
                if(board[x+15].isEmpty()){
                    board[x+15].setBackground(new Color(154,177,252));
                }
                else if (!board[x+15].getForeground().equals(board[x].getForeground())){
                    board[x+15].setBackground(new Color(154,177,252));
                }
            }
        }

        if((x+1)%8 != 0 && (x+2)%8 != 0){
            if (x-6 > -1) {
                if(board[x-6].isEmpty()){
                    board[x - 6].setBackground(new Color(154,177,252));
                }
                else if (!board[x-6].getForeground().equals(board[x].getForeground())){
                    board[x - 6].setBackground(new Color(154,177,252));
                }
            }
            if (x+10 < 64) {
                if(board[x+10].isEmpty()){
                    board[x+10].setBackground(new Color(154,177,252));
                }
                else if (!board[x+10].getForeground().equals(board[x].getForeground())){
                    board[x+10].setBackground(new Color(154,177,252));
                }
            }
        }

        if((x+1)%8 != 0){
            if (x-15 > -1) {
                if(board[x-15].isEmpty()){
                    board[x - 15].setBackground(new Color(154,177,252));
                }
                else if (!board[x-15].getForeground().equals(board[x].getForeground())){
                    board[x - 15].setBackground(new Color(154,177,252));
                }
            }
            if (x+17 < 64) {
                if(board[x+17].isEmpty()){
                    board[x+17].setBackground(new Color(154,177,252));
                }
                else if (!board[x+17].getForeground().equals(board[x].getForeground())){
                    board[x+17].setBackground(new Color(154,177,252));
                }
            }
        }
    }

    public void paintPawn(int x) {
        if (board[x].getForeground().equals(new Color(223,148,246))) {
            if (x - 7 > -1) {
                if(board[x-8].isEmpty()) {
                    board[x - 8].setBackground(new Color(223,148,246));
                }
                if (x % 8 != 0) {
                    if(board[x-9].isEmpty()) {
                        board[x - 9].setBackground(new Color(223,148,246));
                    }
                    else if(!board[x-9].getForeground().equals(board[x].getForeground())){
                        board[x - 9].setBackground(new Color(223,148,246));
                    }
                }
                if ((x + 1) % 8 != 0) {
                    if(board[x-7].isEmpty()) {
                        board[x - 7].setBackground(new Color(223,148,246));
                    }
                    else if(!board[x-7].getForeground().equals(board[x].getForeground())){
                        board[x - 7].setBackground(new Color(223,148,246));
                    }
                }
            }
        } else {
            if (x + 7 < 64) {
                if(board[x+8].isEmpty()) {
                    board[x + 8].setBackground(new Color(223,148,246));
                }
                if (x % 8 != 0) {
                    if(board[x+7].isEmpty()) {
                        board[x+7].setBackground(new Color(223,148,246));
                    }
                    else if(!board[x+7].getForeground().equals(board[x].getForeground())){
                        board[x+7].setBackground(new Color(223,148,246));
                    }
                }
                if ((x + 1) % 8 != 0) {
                    if(board[x+9].isEmpty()) {
                        board[x+9].setBackground(new Color(223,148,246));
                    }
                    else if(!board[x+9].getForeground().equals(board[x].getForeground())){
                        board[x+9].setBackground(new Color(223,148,246));
                    }
                }
            }


        }
    }
    }