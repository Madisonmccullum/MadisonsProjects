// Madison McCullum, Advanced programming and data structure
// This is the main class which creates a new frame
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        try {

            UIManager.setLookAndFeel( UIManager.getCrossPlatformLookAndFeelClassName() );

        }
        catch (Exception e) {

            e.printStackTrace();

        }
        new MyFrame();

    }
}