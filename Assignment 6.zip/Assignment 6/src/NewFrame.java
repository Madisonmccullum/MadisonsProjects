// Madison McCullum, Advanced Programming and data structures
// The purpose of this class NewFrame is to create a new window
// that give the instructions on where each chess player can
// move to
import javax.swing.*;
import java.awt.*;

public class NewFrame extends JFrame{

    JLabel label = new JLabel();
    NewFrame(){

        // creating text area for new window that gives instructions on the players movements
        JTextArea textArea = new JTextArea("""
                Legal movement of pieces on chessboard (according to wikipedia):
                
                King: moves one square in any direction.
                
                Rook: can move any number of squares along a rank or file, but cannot leap over 
                other pieces.
                
                Bishop: can move any number of squares diagonally, but cannot leap over other
                pieces.
                
                Queen: combines the power of a rook and bishop and can move any number of 
                squares along a rank, file, or diagonal, but cannot leap over other pieces.
                
                Knight: moves to any of the closest squares that are not on the same rank, file, 
                or diagonal. (Thus the move forms an "L"-shape: two squares vertically and one 
                square horizontally, or two squares horizontally and one square vertically.) The 
                knight is the only piece that can leap over other pieces.
                
                Pawn: can move forward to the unoccupied square immediately in front of it on the 
                same file, or on its first move it can advance two squares along the same file, 
                provided both squares are unoccupied (black dots in the diagram). A pawn can 
                capture an opponent's piece on a square diagonally in front of it by moving to 
                that square (black crosses). It cannot capture a piece while advancing along the 
                same file.
                """);
        JScrollPane scrollPane = new JScrollPane(textArea);
        textArea.setBorder(BorderFactory.createEmptyBorder(20,20,0,0));
        textArea.setBackground(new Color(248, 210, 220));
        textArea.setForeground(new Color(218, 97, 214));

        // creating new window
        this.setLayout(new BorderLayout());
        this.setTitle("Instructions");
        this.getContentPane().add(scrollPane, BorderLayout.CENTER);
        this.setResizable(false);
        this.setSize(520, 420);
        this.setVisible(true);
    }
}
