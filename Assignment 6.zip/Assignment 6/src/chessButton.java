// Madison McCullum, Advanced Programming and data structures
// The purpose of this chess button class, is to extend the
// JButton class and stretch it to have a number variable
// as well as a player variable
import javax.swing.*;
public class chessButton extends JButton {

    // data members of chess button class
    public int num;
    String player = "null";
    chessButton(int x){
        num = x;
        super.setContentAreaFilled(false);
    }

    // chess button methods
    public void setPlayer(String x){
        player = x;
        this.setText(x);
    }

    public String getPlayer(){
        return player;
    }

    // returns true if button has no player
    public boolean isEmpty(){
        if(player.equals("null")){
            return true;
        }
        return false;
    }

}